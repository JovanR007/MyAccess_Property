import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import mockJobData from '../../_data/jobs.json';
import { Job } from 'src/app/_models/job';

@Injectable({
  providedIn: 'root'
})
export class JobService {

  constructor() { }

  getJobList(): Observable<Job[]> {
    return of(mockJobData as Job[]);
  }
}
