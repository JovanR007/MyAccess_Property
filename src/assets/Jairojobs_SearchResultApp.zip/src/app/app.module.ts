import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchComponent } from './components/search/search/search.component';
import { JobItemComponent } from './components/jobs/job-item/job-item.component';
import { JobListComponent } from './components/jobs/job-list/job-list.component';
import { JobDetailComponent } from './components/jobs/job-detail/job-detail.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { FilterComponent } from './components/search/filter/filter.component';
import { SortByComponent } from './components/search/sort-by/sort-by.component';

@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    JobItemComponent,
    JobListComponent,
    JobDetailComponent,
    PaginationComponent,
    FilterComponent,
    SortByComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
