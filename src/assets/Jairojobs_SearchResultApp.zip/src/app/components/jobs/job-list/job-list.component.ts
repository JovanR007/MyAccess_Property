import { Component, OnInit } from '@angular/core';
import { Job } from 'src/app/_models/job';
import { JobService } from 'src/app/_services/job-service/job.service';

@Component({
  selector: 'app-job-list',
  templateUrl: './job-list.component.html',
  styleUrls: ['./job-list.component.scss']
})
export class JobListComponent implements OnInit {
  jobList: Job[] = [];

  constructor(private jobService: JobService) { }

  ngOnInit(): void {
    this.getJobList();
  }

  getJobList() {
    this.jobService.getJobList()
      .subscribe((jobs) => this.jobList = jobs);
  }
}
