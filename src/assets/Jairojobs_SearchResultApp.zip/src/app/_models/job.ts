export interface Job {
  id: number,
  title: string,
  company: string,
  location: string,
  workType: string,
  minSalary: number,
  maxSalary: number,
  salaryType: string,
  workLocation: string
}
