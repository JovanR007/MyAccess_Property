import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { JobComponent } from './components/jobs/job/job.component';
import { JobListingResolver } from './_resolvers/job-listing.resolver';

const routes: Routes = [
  { path: 'jobs', component: JobComponent },
  { path: 'jobs/:jobTitle', component: JobComponent, resolve: { jobs: JobListingResolver } }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
