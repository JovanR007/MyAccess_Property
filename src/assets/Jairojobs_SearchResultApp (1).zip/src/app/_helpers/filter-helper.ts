import { Filter } from "../_models/_filter/filter";
import { FilterTag } from "../_models/_filter/filter-tag";

export function transformFilterToTags(filter: Filter) : FilterTag[]
{
  var filterTags: FilterTag[] = [];

  if (filter.industry && filter.industry !== 'all')
    filterTags.push({ field: 'Industry', value: filter.industry });

  if (filter.minSalary > 0 || filter.maxSalary > 0)
    filterTags.push({ field: 'Salary Range', value: `P${filter.minSalary} - P${filter.maxSalary}` })

  if (filter.company && filter.company != 'all')
    filterTags.push({ field: 'Company', value: filter.company });

  if (filter.ratings && filter.ratings != 'all')
    filterTags.push({ field: 'Ratings', value: filter.ratings });

  if (filter.employmentType && filter.employmentType !== 'all')
    filterTags.push({ field: 'Employment Type', value: filter.employmentType })

  return filterTags;
}
