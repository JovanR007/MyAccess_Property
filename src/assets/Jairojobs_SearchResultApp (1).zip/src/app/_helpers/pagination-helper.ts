import { PaginatedResult } from "../_models/paginated-result";
import { Pagination } from "../_models/pagination";

export function getPaginatedResult<T>(data: T, pagination: Pagination) {
  const paginatedResult: PaginatedResult<T> = new PaginatedResult<T>();

  paginatedResult.result = data;
  paginatedResult.pagination = pagination;

  return paginatedResult;
}
