export function getNextPageItemToGet(pageNumber: number): [number, number] {
  switch (pageNumber) {
    case 2:
      return [10, 20];
    case 3:
      return [20, 30];
    default:
      return [0, 10];
  }
}
