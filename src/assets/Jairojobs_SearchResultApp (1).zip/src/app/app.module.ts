import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from './_modules/shared.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchComponent } from './components/search/search/search.component';
import { JobItemComponent } from './components/jobs/job-item/job-item.component';
import { JobListComponent } from './components/jobs/job-list/job-list.component';
import { JobDetailComponent } from './components/jobs/job-detail/job-detail.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { FilterComponent } from './components/filter/filter/filter.component';
import { SortByComponent } from './components/search/sort-by/sort-by.component';
import { FeatherIconModule } from './_modules/feather-icon.module';
import { FilterModalComponent } from './components/filter/filter-modal/filter-modal.component';
import { FilterCardComponent } from './components/filter/filter-card/filter-card.component';
import { ApplicationModalComponent } from './components/application/application-modal/application-modal.component';
import { ApplicationSummaryModalComponent } from './components/application/application-summary-modal/application-summary-modal.component';
import { ApplicationConfirmationModalComponent } from './components/application/application-confirmation-modal/application-confirmation-modal.component';
import { JobComponent } from './components/jobs/job/job.component';

@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    JobItemComponent,
    JobListComponent,
    JobDetailComponent,
    PaginationComponent,
    FilterComponent,
    SortByComponent,
    FilterModalComponent,
    FilterCardComponent,
    ApplicationModalComponent,
    ApplicationSummaryModalComponent,
    ApplicationConfirmationModalComponent,
    JobComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    FeatherIconModule,
    SharedModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
