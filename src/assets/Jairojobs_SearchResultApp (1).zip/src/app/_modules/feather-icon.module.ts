import { NgModule } from '@angular/core';

import { FeatherModule } from 'angular-feather';
import {
  ArrowLeft,
  ArrowRight,
  Briefcase,
  Clock,
  Filter,
  Info,
  Search,
  MapPin,
  Users,
  UploadCloud,
  XCircle
} from 'angular-feather/icons';

const icons = {
  ArrowLeft,
  ArrowRight,
  Briefcase,
  Clock,
  Filter,
  Info,
  Search,
  MapPin,
  Users,
  UploadCloud,
  XCircle
}

@NgModule({
  declarations: [],
  imports: [
    FeatherModule.pick(icons)
  ],
  exports: [
    FeatherModule
  ]
})
export class FeatherIconModule { }
