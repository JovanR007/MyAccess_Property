import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { CompanyCategoryFilter } from 'src/app/_models/company-category-filter';
import { EmploymentTypeFilter } from 'src/app/_models/employment-type-filter';
import { Filter } from 'src/app/_models/_filter/filter';
import { IndustryFilter } from 'src/app/_models/industry-filter';
import { RatingFilter } from 'src/app/_models/rating-filter';
import { FilterService } from 'src/app/_services/filter-service/filter.service';

@Component({
  selector: 'app-filter-modal',
  templateUrl: './filter-modal.component.html',
  styleUrls: ['./filter-modal.component.scss']
})
export class FilterModalComponent implements OnInit {
  @Input() filter: Filter | undefined;

  filterForm!: FormGroup;

  industryFilters: IndustryFilter[] = [];
  companyFilters: CompanyCategoryFilter[] = [];
  ratingFilters: RatingFilter[] = [];
  employmentTypeFilters: EmploymentTypeFilter[] = [];

  constructor(
    private bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private filterService: FilterService
  ) { }

  ngOnInit(): void {
    this.initializeFilterForm();
    this.getFilterData();
  }

  initializeFilterForm() {
    this.filterForm = this.fb.group({
      industry: ['all', Validators.required],
      minSalary: [0],
      maxSalary: [0],
      company: ['all'],
      ratings: ['all'],
      employmentType: ['all']
    });
  }

  getFilterData() {
    this.filterService.getIndustryFilter()
      .subscribe((industryFilters) => { this.industryFilters = industryFilters });

    this.filterService.getCompanyCatFilter()
      .subscribe((companyFilters) => { this.companyFilters = companyFilters });

    this.filterService.getRatingFilter()
      .subscribe((ratingFilters) => { this.ratingFilters = ratingFilters });

    this.filterService.getEmploymentTypeFilter()
      .subscribe((employmentTypeFilters) => { this.employmentTypeFilters = employmentTypeFilters });
  }

  onSaveFilter() {
    this.setDisplayTestInsteadOfValue();

    const filter = this.filterForm.value as Filter;

    this.filterService.changeFilter(filter);
    this.bsModalRef.hide();
  }

  onCancel() {
    this.bsModalRef.hide();
  }

  private setDisplayTestInsteadOfValue() {
    var industry = this.industryFilters.find(x => x.value === this.filterForm.get('industry')?.value);
    if (industry)
      this.filterForm.get('industry')?.setValue(industry.display);

    var company = this.companyFilters.find(x => x.value === this.filterForm.get('company')?.value);
    if (company)
      this.filterForm.get('company')?.setValue(company.display);

    var ratings = this.ratingFilters.find(x => x.value === this.filterForm.get('ratings')?.value);
    if (ratings)
      this.filterForm.get('ratings')?.setValue(ratings.display);

    var employmentType = this.employmentTypeFilters.find(x => x.value === this.filterForm.get('employmentType')?.value);
    if (employmentType)
      this.filterForm.get('employmentType')?.setValue(employmentType.display);
  }
}
