import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Filter } from 'src/app/_models/_filter/filter';
import { FilterTag } from 'src/app/_models/_filter/filter-tag';
import { FilterService } from 'src/app/_services/filter-service/filter.service';

@Component({
  selector: 'app-filter-card',
  templateUrl: './filter-card.component.html',
  styleUrls: ['./filter-card.component.scss']
})
export class FilterCardComponent implements OnInit, OnDestroy {
  @Input() Filter: Filter | undefined;

  subscription: Subscription | undefined;
  filterTags: FilterTag[] = [];

  constructor(private filterService: FilterService) {
  }

  ngOnInit(): void {
    this.subscription = this.filterService.currentFilterTags$.subscribe((tags) => this.filterTags = tags);
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

  onRemoveFilter(index: number) {
    this.filterTags.splice(index, 1);

    this.filterService.removeFilterTag(this.filterTags);
  }
}
