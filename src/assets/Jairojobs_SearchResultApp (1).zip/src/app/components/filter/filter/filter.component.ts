import { Component, OnInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FilterModalComponent } from '../filter-modal/filter-modal.component';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {
  bsModalRef: BsModalRef | undefined;

  constructor(
    private modalService: BsModalService
  ) { }

  ngOnInit(): void {
  }

  onOpenFilterModal() {
    const config = {
      class: 'modal-dialog-centered',
      initialState: {
        filter: undefined
      }
    }

    this.bsModalRef = this.modalService.show(FilterModalComponent, config);
  }
}
