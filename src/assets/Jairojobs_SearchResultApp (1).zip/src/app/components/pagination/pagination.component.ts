import { Component, Input, OnInit } from '@angular/core';
import { Pagination } from 'src/app/_models/pagination';
import { MAX_PAGE_LINK_SIZE } from 'src/app/_constants/pagination-constant';
import { JobService } from 'src/app/_services/job-service/job.service';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit {
  @Input() pagination: Pagination | undefined;

  constructor(
    public jobService: JobService
  ) { }

  ngOnInit(): void {

  }

  pageChanged(event: any) {
    this.jobService.getJobList(event.page);
  }
}
