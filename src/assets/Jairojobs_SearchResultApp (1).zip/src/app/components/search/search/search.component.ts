import { Component, OnInit } from '@angular/core';
import { JobService } from 'src/app/_services/job-service/job.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {

  constructor(
    private jobService: JobService
  ) { }

  ngOnInit(): void {

  }

  searchJobTitle(event: any) {
    const jobTitle = event.target.value;

    setTimeout(() => {
      this.jobService.searchJob(jobTitle);
    }, 2000);
  }
}
