import { Component, Input, OnInit } from '@angular/core';
import { SortOrder } from 'src/app/_enums/sort-order.enum';

@Component({
  selector: 'app-sort-by',
  templateUrl: './sort-by.component.html',
  styleUrls: ['./sort-by.component.scss']
})
export class SortByComponent implements OnInit {
  @Input() defaultSortState!: SortOrder;
  selectedSortOrder!: SortOrder;

  constructor() { }

  ngOnInit(): void {
    this.selectedSortOrder = this.defaultSortState!
  }

  onChangeSortOrder() {
    if (this.selectedSortOrder === SortOrder.asc)
      this.selectedSortOrder = SortOrder.desc;
    else
      this.selectedSortOrder = SortOrder.asc;
  }
}
