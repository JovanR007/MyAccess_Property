import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-application-confirmation-modal',
  templateUrl: './application-confirmation-modal.component.html',
  styleUrls: ['./application-confirmation-modal.component.scss']
})
export class ApplicationConfirmationModalComponent implements OnInit {
  jobTitle: string | undefined;

  constructor(private bsModalRef: BsModalRef) { }

  ngOnInit(): void {
  }

  onDone() {
    this.bsModalRef.hide();
  }
}
