import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationConfirmationModalComponent } from './application-confirmation-modal.component';

describe('ApplicationConfirmationModalComponent', () => {
  let component: ApplicationConfirmationModalComponent;
  let fixture: ComponentFixture<ApplicationConfirmationModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApplicationConfirmationModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationConfirmationModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
