import { Component, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Application } from 'src/app/_models/application';
import { ApplicationConfirmationModalComponent } from '../application-confirmation-modal/application-confirmation-modal.component';
import { ApplicationModalComponent } from '../application-modal/application-modal.component';

@Component({
  selector: 'app-application-summary-modal',
  templateUrl: './application-summary-modal.component.html',
  styleUrls: ['./application-summary-modal.component.scss']
})
export class ApplicationSummaryModalComponent implements OnInit {
  application: Application | undefined;

  constructor(
    private bsModalRef: BsModalRef,
    private modalService: BsModalService
  ) { }

  ngOnInit(): void {
  }

  onApplyJob() {
    const config = {
      class: 'modal-dialog-centered modal-lg',
      initialState: {
        jobTitle: this.application?.appliedJob.title
      }
    }

    this.bsModalRef = this.modalService.show(ApplicationConfirmationModalComponent, config);
    this.bsModalRef.hide();
  }

  onBack() {
    const config = {
      class: 'modal-dialog-centered modal-lg',
      initialState: {
        application: this.application
      }
    }

    this.modalService.show(ApplicationModalComponent, config);
    this.bsModalRef.hide();
  }
}
