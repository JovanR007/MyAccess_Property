import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Subscription } from 'rxjs';
import { Application } from 'src/app/_models/application';
import { Job } from 'src/app/_models/job';
import { JobService } from 'src/app/_services/job-service/job.service';
import { ApplicationSummaryModalComponent } from '../application-summary-modal/application-summary-modal.component';

@Component({
  selector: 'app-application-modal',
  templateUrl: './application-modal.component.html',
  styleUrls: ['./application-modal.component.scss']
})
export class ApplicationModalComponent implements OnInit, OnDestroy {
  subscription: Subscription | undefined;
  job: Job | undefined;

  applicationForm!: FormGroup;

  application: Application | undefined;

  constructor(
    private bsModalRef: BsModalRef,
    private fb: FormBuilder,
    private jobService: JobService,
    private modalService: BsModalService
  ) { }

  ngOnInit(): void {
    this.subscription = this.jobService.currentJobDetail$
      .subscribe((job) => this.job = job);

    this.initializeForm();

    if (this.application) {
      this.applicationForm.setValue(this.application);
    }
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

  initializeForm() {
    this.applicationForm = this.fb.group({
      firstName: [null, Validators.required],
      lastName: [null, Validators.required],
      email: [null, [Validators.required, Validators.email]],
      phone: [null, Validators.required],
      appliedJob: this.job
    });
  }

  onContinue() {
    const config = {
      class: 'modal-dialog-centered modal-lg',
      initialState: {
        application: (this.applicationForm.value as Application)
      }
    }

    this.modalService.show(ApplicationSummaryModalComponent, config);
    this.bsModalRef.hide();
  }

  onCancel() {
    this.bsModalRef.hide();
  }
}
