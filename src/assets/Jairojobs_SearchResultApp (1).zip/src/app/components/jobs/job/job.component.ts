import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { SortOrder } from 'src/app/_enums/sort-order.enum';
import { Job } from 'src/app/_models/job';
import { Pagination } from 'src/app/_models/pagination';
import { JobService } from 'src/app/_services/job-service/job.service';

@Component({
  selector: 'app-job',
  templateUrl: './job.component.html',
  styleUrls: ['./job.component.scss']
})
export class JobComponent implements OnInit {
  defaultSortOrder = SortOrder;

  jobLists: Job[] = [];
  pagination: Pagination | undefined;

  constructor(
    public jobService: JobService,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap) => {
      const jobTitle = params.get('jobTitle');

      if (!jobTitle) {
        this.jobService.getJobList(1);
      }
    });
  }
}
