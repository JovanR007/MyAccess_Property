import { Component, OnDestroy, OnInit } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Subscription } from 'rxjs';
import { Job } from 'src/app/_models/job';
import { JobService } from 'src/app/_services/job-service/job.service';
import { ApplicationModalComponent } from '../../application/application-modal/application-modal.component';

@Component({
  selector: 'app-job-detail',
  templateUrl: './job-detail.component.html',
  styleUrls: ['./job-detail.component.scss']
})
export class JobDetailComponent implements OnInit, OnDestroy {
  subscription: Subscription | undefined;
  job: Job | undefined;

  bsModalRef: BsModalRef | undefined;

  constructor(
    private jobService: JobService,
    private modalService: BsModalService
  ) { }

  ngOnInit(): void {
    this.subscription = this.jobService.currentJobDetail$
      .subscribe((job) => this.job = job);
  }

  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }

  onApplyJob(job: Job) {
    const config = {
      class: 'modal-dialog-centered modal-lg'
    }

    this.bsModalRef = this.modalService.show(ApplicationModalComponent, config);
  }
}
