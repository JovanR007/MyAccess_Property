import { Component, Input, OnInit } from '@angular/core';
import { Job } from 'src/app/_models/job';
import { JobService } from 'src/app/_services/job-service/job.service';

@Component({
  selector: 'app-job-item',
  templateUrl: './job-item.component.html',
  styleUrls: ['./job-item.component.scss']
})
export class JobItemComponent implements OnInit {
  @Input() job: Job | undefined;

  constructor(public jobService: JobService) { }

  ngOnInit(): void {
  }

  onSelectedJob(job: Job) {
    this.jobService.getJobDetail(job.id);
  }
}
