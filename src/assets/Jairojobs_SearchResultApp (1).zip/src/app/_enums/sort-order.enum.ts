export enum SortOrder {
  asc = 'A-Z',
  desc = 'Z-A'
}
