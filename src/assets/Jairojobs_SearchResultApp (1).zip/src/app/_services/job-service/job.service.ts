import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import mockJobData from '../../_data/jobs.json';
import { Job } from 'src/app/_models/job';
import { getPaginatedResult } from 'src/app/_helpers/pagination-helper';
import { Pagination } from 'src/app/_models/pagination';
import { ITEMS_PER_PAGE, MAX_PAGE_LINK_SIZE } from 'src/app/_constants/pagination-constant';
import { PaginatedResult } from 'src/app/_models/paginated-result';
import { getNextPageItemToGet } from 'src/app/_helpers/item-helper';

@Injectable({
  providedIn: 'root'
})
export class JobService {
  private jobDetailSource = new BehaviorSubject<Job | undefined>(undefined);
  currentJobDetail$ = this.jobDetailSource.asObservable();

  private jobListsSource = new BehaviorSubject<PaginatedResult<Job[]> | undefined>(undefined);
  currentJobLists$ = this.jobListsSource.asObservable();

  constructor() { }

  getJobList(pageNumber: number) {
    const mockDatas = this.getJobListMockData();

    const item = getNextPageItemToGet(pageNumber);
    const jostLists = mockDatas.slice(item[0], item[1]);
    const pagination = this.resetPagination(mockDatas.length);
    pagination.currentPage = pageNumber;

    const paginationJobLists = getPaginatedResult<Job[]>(jostLists, pagination);
    this.jobListsSource.next(paginationJobLists);
    this.jobDetailSource.next(jostLists[0]);
  }

  getJobDetail(jobId: number) {
    const mockDatas = this.getJobListMockData();
    const job = mockDatas.find(x => x.id === jobId)!;

    this.jobDetailSource.next(job);
  }

  searchJob(jobTitle: string, pageNumber?: number) {
    const mockDatas = this.getJobListMockData();

    const results = mockDatas.filter(x => x.title.toLowerCase().includes(jobTitle.toLowerCase()));

    const item = getNextPageItemToGet(pageNumber ?? 1);
    const jostLists = results.slice(item[0], item[1]);
    const pagination = this.resetPagination(results.length);
    pagination.currentPage = pageNumber ?? 1;

    const paginationJobLists = getPaginatedResult<Job[]>(jostLists, pagination);
    this.jobListsSource.next(paginationJobLists);
    this.jobDetailSource.next(jostLists[0]);
  }

  private getJobListMockData(): Job[] {
    return mockJobData as Job[];
  }

  private resetPagination(totalItems?: number) {
    const pagination: Pagination = {
      currentPage: 1,
      itemsPerPage: ITEMS_PER_PAGE,
      maxPageLinkSize: MAX_PAGE_LINK_SIZE,
      totalItems: totalItems ? totalItems : 0
    };

    return pagination;
  }
}
