import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';

import { Filter } from 'src/app/_models/_filter/filter';

import { CompanyCategoryFilter } from 'src/app/_models/company-category-filter';
import { RatingFilter } from 'src/app/_models/rating-filter';
import { EmploymentTypeFilter } from 'src/app/_models/employment-type-filter';
import { IndustryFilter } from 'src/app/_models/industry-filter';

import mockRatingData from '../../_data/rating-filter.json';
import mockCompCatData from '../../_data/company-category-filter.json';
import mockEmploymentTypeData from '../../_data/employment-type-filter.json';
import mockIndustryData from '../../_data/industry-filter.json';
import { FilterTag } from 'src/app/_models/_filter/filter-tag';
import { transformFilterToTags } from 'src/app/_helpers/filter-helper';


@Injectable({
  providedIn: 'root'
})
export class FilterService {
  private filterTagSource = new BehaviorSubject<FilterTag[]>([]);
  currentFilterTags$ = this.filterTagSource.asObservable();

  constructor() { }

  changeFilter(filter: Filter) {
    const filterTags = transformFilterToTags(filter);

    this.filterTagSource.next(filterTags);
  }

  removeFilterTag(tags: FilterTag[]) {
    this.filterTagSource.next(tags);
  }

  getIndustryFilter(): Observable<IndustryFilter[]> {
    const industries = mockIndustryData as IndustryFilter[];

    return of(industries);
  }

  getCompanyCatFilter(): Observable<CompanyCategoryFilter[]> {
    const companyCategories = mockCompCatData as CompanyCategoryFilter[];

    return of(companyCategories);
  }

  getRatingFilter(): Observable<RatingFilter[]> {
    const ratings = mockRatingData as RatingFilter[];

    return of(ratings);
  }

  getEmploymentTypeFilter(): Observable<EmploymentTypeFilter[]> {
    const employmentTypes = mockEmploymentTypeData as EmploymentTypeFilter[];

    return of(employmentTypes);
  }
}
