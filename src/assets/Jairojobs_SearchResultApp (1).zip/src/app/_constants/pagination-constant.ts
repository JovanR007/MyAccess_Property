/** maximum number of items per page. If value less than 1 will display all items on one page */
export const ITEMS_PER_PAGE: number = 10;
/** limit number for page links in pager */
export const MAX_PAGE_LINK_SIZE: number = 5;

