import { Injectable } from '@angular/core';
import {
  Resolve,
  ActivatedRouteSnapshot
} from '@angular/router';
import { JobService } from '../_services/job-service/job.service';

@Injectable({
  providedIn: 'root'
})
export class JobListingResolver implements Resolve<void> {
  constructor(private jobService: JobService) { }

  resolve(route: ActivatedRouteSnapshot) {
    return this.jobService.searchJob(route.paramMap.get('jobTitle')!);
  }
}
