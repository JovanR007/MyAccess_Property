import { Job } from "./job";

export interface Application {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  appliedJob: Job;
}
