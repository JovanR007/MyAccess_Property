export interface IndustryFilter {
  value: string;
  display: string;
}
