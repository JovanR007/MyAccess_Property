export interface Job {
  id: number,
  title: string,
  company: string,
  location: string,
  employmentType: string,
  minSalary: number,
  maxSalary: number,
  salaryType: string,
  workLocation: string,
  industry: string,
  appliedCount: number,
  jobDescription: string
}
