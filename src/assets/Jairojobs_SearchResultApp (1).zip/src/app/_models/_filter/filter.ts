export interface Filter {
  industry: string,
  minSalary: number,
  maxSalary: number,
  company: string,
  ratings: string,
  employmentType: string
}
