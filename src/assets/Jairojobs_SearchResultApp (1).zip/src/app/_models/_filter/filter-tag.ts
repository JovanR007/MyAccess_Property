export interface FilterTag {
  field: string;
  value: string;
}
