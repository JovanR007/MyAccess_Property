export interface CompanyCategoryFilter {
  value: string;
  display: string;
}
