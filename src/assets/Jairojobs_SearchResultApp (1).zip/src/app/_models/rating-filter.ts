export interface RatingFilter {
  value: string;
  display: string;
}
