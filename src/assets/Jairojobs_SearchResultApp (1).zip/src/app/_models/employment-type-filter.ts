export interface EmploymentTypeFilter {
  value: string;
  display: string;
}
