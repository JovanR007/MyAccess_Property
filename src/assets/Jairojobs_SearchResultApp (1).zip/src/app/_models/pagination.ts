export interface Pagination {
  currentPage: number;
  itemsPerPage: number;
  totalItems: number;
  maxPageLinkSize: number;
}
