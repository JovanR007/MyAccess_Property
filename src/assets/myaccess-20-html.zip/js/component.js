class Navbar extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `
        <nav class="navbar navbar-expand-lg customized_nav_color">
        <div class="container">
            <a class="navbar-brand" href="#"><img src="/Assets/images/Stevenson_Systems_Logo_icon 1.png" alt="" width="40px" height="41"></a>
           



            </div>
            </div>
        </div>
        </nav>
        `
    }
}



// class Footer extends HTMLElement {
//     connectedCallback() {
//         this.innerHTML = `
//         <footer class="customized_footer">
//         <div class="footer-wrapper">
//             <img src="/Assets/images/Stevenson_Systems_Logo_icon 1.png" alt="" width="51" height="57">
//             <div class="content_address">
//                 <p>
//                     Stevenson Systems, Inc.<br>
//                     27882 El Lazo Road<br>
//                     Laguna Niguel, CA 92677 
//                     Contact Us
//                 </p>
//             </div>
//         </div>
//     </footer>  


//         `
//     }
// }

class Modal extends HTMLElement {
    connectedCallback() {
        this.innerHTML = `

        <button class="forget-password" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalB" id="testBtn">
        <a class="text-dark"href="#">Forget Password?</a>
        </button>
        
        <div class="modal fade customized_modal" id="exampleModalB" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
            <div style="width: 627px; height: 294px;" class="modal-content">
                <div class="modal-header">
                <p style="font-size: 24px; font-family: New Rail Alphabet; line-height: 24.22px; font-weight: 300" class="modal-title" id="exampleModalLabel">Forgot Password Form</p>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body modal-body-wrapper">
                    <p style="font-size: 14px; font-family: New Rail Alphabet; line-height: 14.13px; font-weight: 300">We just need your registered Email to send you a new password.</p>
                    <input type="email" class="form-control modal-input" placeholder="Email">
                </div>
                <div class="modal-footer custom-modal-footer">

                <button type="button" class="btn confirm-modal" id="changePassConfirmBtn" data-bs-dismiss="modal">Confirm</button>

                <button type="button" class="btn close-modal" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
            </div>
        </div>

        
        `
    }
}

customElements.define('site-modal', Modal);
// class ModalC extends HTMLElement {
//     connectedCallback() {
//         this.innerHTML = `

//         <button style="border: none; background-color: white; font-family: New Rail Alphabet" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalC">
//         <a class="text-dark"href="#">Forget Password?</a>
//         </button>
        
//         <div class="modal fade customized_modal" id="exampleModalC" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
//             <div class="modal-dialog">
//             <div style="width: 627px; height: 294px;" class="modal-content ">
//                 <div class="modal-header">
//                 <p style="font-size: 24px; font-family: New Rail Alphabet; line-height: 24.22px; font-weight: 300" class="modal-title" id="exampleModalLabel">Forgot Password Form</p>
//                 <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
//                 </div>
//                 <div class="modal-body m-3 mb-4">
//                     <p style="font-size: 14px; font-family: New Rail Alphabet; line-height: 14.13px; font-weight: 300">We just need your registered Email to send you a new password.</p>
//                     <input type="email" class="form-control" placeholder="Email">
//                 </div>
//                 <div class="modal-footer">

//                 <button style="background-color: #483A49; width: 152.58px; height: 40px; font-family: New Rail Alphabet; font-size: 14px; line-height: 14.13px;" type="button" class="btn text-light" id="changePassConfirmBtn" data-bs-dismiss="modal">Confirm</button>

//                 <button style="background-color: #483A49; width: 152.58px; height: 40px; font-family: New Rail Alphabet; font-size: 14px; line-height: 14.13px;" type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
//                 </div>
//             </div>
//             </div>
//         </div>

        
//         `
//     }
// }

// class ModalD extends HTMLElement {
//     connectedCallback() {
//         this.innerHTML = `

//         <button style="border: none; background-color: white; font-family: New Rail Alphabet" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalD">
//         <a class="text-dark"href="#">Forget Password?</a>
//         </button>
        
//         <div class="modal fade customized_modal" id="exampleModalD" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
//             <div class="modal-dialog">
//             <div style="width: 627px; height: 294px;" class="modal-content ">
//                 <div class="modal-header">
//                 <p style="font-size: 24px; font-family: New Rail Alphabet; line-height: 24.22px; font-weight: 300" class="modal-title" id="exampleModalLabel">Forgot Password Form</p>
//                 <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
//                 </div>
//                 <div class="modal-body m-3 mb-4">
//                     <p style="font-size: 14px; font-family: New Rail Alphabet; line-height: 14.13px; font-weight: 300">We just need your registered Email to send you a new password.</p>
//                     <input type="email" class="form-control" placeholder="Email">
//                 </div>
//                 <div class="modal-footer">

//                 <button style="background-color: #483A49; width: 152.58px; height: 40px; font-family: New Rail Alphabet; font-size: 14px; line-height: 14.13px;" type="button" class="btn text-light" id="changePassConfirmBtn" data-bs-dismiss="modal">Confirm</button>

//                 <button style="background-color: #483A49; width: 152.58px; height: 40px; font-family: New Rail Alphabet; font-size: 14px; line-height: 14.13px;" type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
//                 </div>
//             </div>
//             </div>
//         </div>

        
//         `
//     }
// }
customElements.define('site-navbar', Navbar);
customElements.define('site-footer', Footer);

// customElements.define('site-modaltwo', ModalC);
// customElements.define('site-modalthree', ModalD);
