var emailForm = document.getElementById('emailForm');
var emailField = document.getElementById('emailField');
var passwordField = document.getElementById('passwordField');
var confirmBtn = document.querySelector('.confirmBtn')
var firstStep = document.getElementById('firstStep');

// from modal
var changePassConfirmBtn = document.getElementById('changePassConfirmBtn');

//password
var cancelButton = document.getElementById('cancelButton');

//first step auth
var firstStepCancelBtn = document.getElementById('firstStepCancelBtn');
var firstStepSendCodeBtn = document.getElementById('firstStepSendCodeBtn');

//second step auth
var secondStep = document.getElementById('secondStep');
var secondStepCancelBtn = document.getElementById('secondStepCancelBtn');


function proceed(e) {
    e.preventDefault();
    passwordField.style.display = "block";
    emailField.style.display = "none";
}
confirmBtn.addEventListener('click', proceed);


function cancel(e) {
    e.preventDefault();
    passwordField.style.display = "none";
    emailField.style.display = "block";
}
cancelButton.addEventListener('click', cancel);


//button confirm to change password for modal
function confirmChangePass(e) {
    e.preventDefault();
    emailField.style.display = "none";
    firstStep.style.display = "block";
}
changePassConfirmBtn.addEventListener('click', confirmChangePass);


function firstStepAuthCancel(e) {
    e.preventDefault();
    firstStep.style.display = "none";
    emailField.style.display = "block";
}
firstStepCancelBtn.addEventListener('click', firstStepAuthCancel);

function firstStepAuthConfirm(e) {
    e.preventDefault();
    secondStep.style.display = "block"
    firstStep.style.display = "none";
}
firstStepSendCodeBtn.addEventListener('click', firstStepAuthConfirm);

function secondStepAuthCancel(e) {
    e.preventDefault();
    firstStep.style.display = "block";
    secondStep.style.display = "none"
}
secondStepCancelBtn.addEventListener('click', secondStepAuthCancel);



