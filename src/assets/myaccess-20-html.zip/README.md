# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Installation process
2.	Software dependencies
3.	Latest releases
4.	API references

# Build and Test
TODO: Describe and show how to build your code and run the tests. 

# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)



<i class="fas fa-sort"></i>

    <div class="sub-header">
        <ul class="nav nav-pills justify-content-center mb-3" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active pt-lg-3" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home"
                    type="button" role="tab" aria-controls="pills-home" aria-selected="true">
            <!--icon-->
        <img src="assets/images/active-members.png" class="buttonIconPill"><br>
                <p id="buttonTextPills" class="mt-lg-3">
                    Active<br>
                    Members
                </p>
               
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link pt-lg-3" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile"
                    type="button" role="tab" aria-controls="pills-profile" aria-selected="false">
                <img src="assets/images/pending-invites.png" class="buttonIconPill"><br>
                <p id="buttonTextPills" class="mt-lg-3">
                    Pending<br>
                    Invites
                </p>
                </button>
            </li>
        </ul>
    </div>


                <li class="nav-item" role="presentation">
                <button class="nav-link pt-lg-3" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-proplist"
                    type="button" role="tab" aria-controls="pills-home" aria-selected="true">
            <!--icon-->
        <img src="assets/images/icon-company-details.png" class="buttonIconPill"><br>
                <p id="buttonTextPills" class="mt-lg-3">
                    Property<br>
                    Summary
                </p>
               
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link pt-lg-3" id="pills-map-tab" data-bs-toggle="pill" data-bs-target="#pills-map"
                    type="button" role="tab" aria-controls="pills-map" aria-selected="false">
                <img src="assets/images/icon-company-properties.png" class="buttonIconPill"><br>
                <p id="buttonTextPills" class="mt-lg-3">
                    Floor<br>
                    and Tenants
                </p>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link pt-lg-3" id="pills-map-tab" data-bs-toggle="pill" data-bs-target="#pills-map"
                    type="button" role="tab" aria-controls="pills-map" aria-selected="false">
                <img src="assets/images/icon-stacking-plan.png" class="buttonIconPill"><br>
                <p id="buttonTextPills" class="mt-lg-3">
                    Stacking<br>
                    Plan
                </p>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link pt-lg-3" id="pills-map-tab" data-bs-toggle="pill" data-bs-target="#pills-map"
                    type="button" role="tab" aria-controls="pills-map" aria-selected="false">
                <img src="assets/images/icon-property-reports.png" class="buttonIconPill"><br>
                <p id="buttonTextPills" class="mt-lg-3">
                    Category<br>
                    Summary
                </p>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link active pt-lg-3" id="pills-map-tab" data-bs-toggle="pill" data-bs-target="#pills-map"
                    type="button" role="tab" aria-controls="pills-map" aria-selected="false">
                <img src="assets/images/icon-space-accounting.png" class="buttonIconPill"><br>
                <p id="buttonTextPills" class="mt-lg-3">
                    SSI<br>
                    Report
                </p>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link pt-lg-3" id="pills-map-tab" data-bs-toggle="pill" data-bs-target="#pills-map"
                    type="button" role="tab" aria-controls="pills-map" aria-selected="false">
                <img src="assets/images/icon-value-opportunity-listing.png" class="buttonIconPill"><br>
                <p id="buttonTextPills" class="mt-lg-3">
                    Value<br>
                    Opportunity
                </p>
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link pt-lg-3" id="pills-map-tab" data-bs-toggle="pill" data-bs-target="#pills-map"
                    type="button" role="tab" aria-controls="pills-map" aria-selected="false">
                <img src="assets/images/icon-users.png" class="buttonIconPill"><br>
                <p id="buttonTextPills" class="mt-lg-3">
                    Property<br>
                    Team Member
                </p>
                </button>
            </li>
            <hr></hr>